import java.util.HashMap;
import java.util.Map;

public class StoreInventory {
	private Map<Integer, Product> inventory;

	public StoreInventory() {
		this.inventory = new HashMap<>();
	}

	public Map<Integer, Product> getInventory() {
		return inventory;
	}

	public void addProduct(Product product) {
		inventory.put(product.getId(), product);
	}

	public void removeProduct(int id) {
		inventory.remove(id);
	}

	public void updateProduct(int id, int quantity) {
		Product product = inventory.get(id);
		if (product != null) {
			product.setQuantity(quantity);
		}
	}

	public void viewCurrentInventory() {
		for (Product product : inventory.values()) {
			System.out.println(product);
		}
	}

	public double calculateTotal() {
		double totalValue = 0;
		for (Product product : inventory.values()) {
			totalValue += product.getPrice() * product.getQuantity();
		}
		return totalValue;
	}
}
