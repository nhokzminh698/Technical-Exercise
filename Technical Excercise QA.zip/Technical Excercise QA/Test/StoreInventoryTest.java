import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class StoreInventoryTest {
	StoreInventory storeInventory;

	@BeforeEach
	void setup() {
		storeInventory = new StoreInventory();
	}

	@Test
	void adding_a_new_product() {
		Product product = new Product("Calculator", 1, 20.00, 20);
		storeInventory.addProduct(product);
		assertEquals(product, storeInventory.getInventory().get(1));
	}

	@Test
	void removing_a_product() {
		Product product = new Product("Calculator", 1, 20.00, 20);
		storeInventory.addProduct(product);
		storeInventory.removeProduct(1);
		assertNull(storeInventory.getInventory().get(1));
	}

	@Test
	void updating_the_quantity_of_a_product() {
		Product product = new Product("Calculator", 1, 20.00, 20);
		storeInventory.addProduct(product);
		storeInventory.updateProduct(1, 15);
		assertEquals(15, storeInventory.getInventory().get(1).getQuantity());
	}

	@Test
	void view_current_inventory() {
		Product product1 = new Product("Calculator", 1, 20.00, 20);
		Product product2 = new Product("Computer", 2, 500.00, 10);
		storeInventory.addProduct(product1);
		storeInventory.addProduct(product2);
		storeInventory.viewCurrentInventory();
	}

	@Test
	void calculate_total_value() {
		Product product1 = new Product("Calculator", 1, 20.00, 20);
		Product product2 = new Product("Computer", 2, 500.00, 10);
		storeInventory.addProduct(product1);
		storeInventory.addProduct(product2);
		double totalValue = storeInventory.calculateTotal();
		assertEquals(5400.00, totalValue);

	}
}
